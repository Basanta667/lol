// Example: Inject message into Pterodactyl dashboard using Blueprint framework
// Save this as index.js inside your extension folder.
Blueprint.onReady(() => {
  const target = document.querySelector("#app");
  if (target) {
    const msg = document.createElement("div");
    msg.innerText = "👋 Hello from Blueprint Extension!";
    msg.className = "hello-world-box";
    // Prepend so it shows at the top of the app content
    target.prepend(msg);
  }
});
