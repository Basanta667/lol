HelloWorld Blueprint Extension
==============================

Files included:
- HelloWorld/manifest.json
- HelloWorld/index.js
- HelloWorld/style.css

Step-by-step (quick):
1. Download and extract the ZIP into your Pterodactyl panel root or your local machine.
   - If you extract on the panel server, place the folder at:
     /var/www/pterodactyl/.blueprint/dev/HelloWorld

2. Build & reload Blueprint (on the panel server):
```bash
cd /var/www/pterodactyl
# Ensure extension is at .blueprint/dev/HelloWorld
php artisan blueprint:build HelloWorld
php artisan blueprint:reload
```

Alternative: If you cannot run `php artisan blueprint:build`:
- Copy the HelloWorld folder into `.blueprint/dev/HelloWorld` and then run `php artisan blueprint:reload`.
- Or restart your panel webserver if `blueprint:reload` is not available.

Manual file creation (if you prefer commands):
```bash
# create folder
mkdir -p /var/www/pterodactyl/.blueprint/dev/HelloWorld

# create manifest.json
cat > /var/www/pterodactyl/.blueprint/dev/HelloWorld/manifest.json <<'JSON'
{
  "id": "hello-world",
  "name": "Hello World Extension",
  "description": "Adds a hello message to the Pterodactyl dashboard",
  "author": "Nick",
  "version": "1.0.0",
  "entry": "index.js",
  "style": "style.css"
}
JSON

# create index.js
cat > /var/www/pterodactyl/.blueprint/dev/HelloWorld/index.js <<'JS'
Blueprint.onReady(() => {
  const target = document.querySelector("#app");
  if (target) {
    const msg = document.createElement("div");
    msg.innerText = "👋 Hello from Blueprint Extension!";
    msg.className = "hello-world-box";
    target.prepend(msg);
  }
});
JS

# create style.css
cat > /var/www/pterodactyl/.blueprint/dev/HelloWorld/style.css <<'CSS'
.hello-world-box {
  background: linear-gradient(45deg, #ff0099, #493240);
  color: white;
  font-weight: bold;
  text-align: center;
  padding: 12px;
  margin-bottom: 10px;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(255, 0, 150, 0.5);
}
CSS
```

Notes & Troubleshooting:
- If you don't see the message: confirm Blueprint is installed and `Blueprint.onReady` is the correct hook for your Blueprint version.
- If panel has caching, try clearing caches or restarting webserver (nginx/php-fpm).
- If you want a packaged `.blueprint` file instead of a folder, run `php artisan blueprint:build HelloWorld` on the panel machine.

If you want, I can also provide a small `build.sh` to automate the build step or a Docker Compose example to run a test Pterodactyl environment — tell me which.
